
for(let num = 1; num <= 10; num++) {
    
    console.log( num );

}console.log()